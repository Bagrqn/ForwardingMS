﻿namespace FMS.Services.Models.Country
{
    public class CountryListingServiceModel
    {
        public int ID { get; set; }

        public string Name { get; set; }
    }
}
