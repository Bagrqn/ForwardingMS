﻿namespace FMS.Services.Models.Postcode
{
    public class PostcodeListingServiceModel
    {
        public int ID { get; set; }

        public string Code { get; set; }
    }
}
