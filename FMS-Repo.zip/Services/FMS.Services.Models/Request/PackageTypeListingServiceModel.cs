﻿namespace FMS.Services.Models.Request
{
    public class PackageTypeListingServiceModel
    {
        public int ID { get; set; }

        public string Name { get; set; }
    }
}
