﻿namespace FMS.Services.Models.Request
{
    public class RequestStatusServiceModel
    {
        public int ID { get; set; }

        public double Code { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}
