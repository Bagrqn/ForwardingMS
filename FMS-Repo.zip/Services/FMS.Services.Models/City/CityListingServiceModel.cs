﻿namespace FMS.Services.Models.City
{
    public class CityListingServiceModel
    {
        public int ID { get; set; }

        public string Name { get; set; }
    }
}
